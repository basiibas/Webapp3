using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Faq.Models;
using Microsoft.AspNetCore.Mvc;

namespace Faq.Controllers
{
    [Route("api/[controller]")]
    public class HomeController : Controller
    {
        private readonly DBModel _context;
        
        public HomeController(DBModel context)
        {
            _context = context;
        }

      //GET api/Home
        [HttpGet("{kategori}")]
        public JsonResult Get(string kategori)
        {
            var sporsmolDb = new SporsmalDB(_context);
            List<Sporsmal> alleSporsmal;

            switch (kategori)
            {
                case "Film":
                    alleSporsmal = sporsmolDb.hentFilmerSporsmal();
                    break;
                case "Order":
                    alleSporsmal = sporsmolDb.hentOrderSporsmal();
                    break;
                case "Bruker":
                    alleSporsmal = sporsmolDb.hentBrukerSporsmal();
                    break;
                case "Alle":
                    alleSporsmal = sporsmolDb.hentAlleSporsmal();
                    break;
                default:
                    alleSporsmal = sporsmolDb.hentSporsmalEtterSok(kategori);
                    break;
            }

            return Json(alleSporsmal);
        }


        /*
        //GET api/Home
        [HttpGet("{tekst:alpha}")]
        public JsonResult Get(string tekst)
        {

            var sporsmolDb = new SporsmalDB(_context);
            //Ta tekste og legge til space
            List<Sporsmal> alleSporsmal = sporsmolDb.hentSporsmalEtterSok(tekst);

            return Json(alleSporsmal);
        }
        */


        // PUT api/Home/5
        
        [HttpPut("{tekst}")]
        public JsonResult Put(string tekst)
        {

            List<String> str = tekst.Split(',').ToList();
            int id = int.Parse(str[0]);
            bool tommel = bool.Parse(str[1]);

            bool OK;
            if (ModelState.IsValid)
            {
                var Db = new SporsmalDB(_context);

                    OK = Db.setNyVurdering(id, tommel);
                
 
                if (OK)
                {
                    return Json("OK");
                }
            }
            return Json("Kunne ikke sett true til false eller omvendt");
        }
        
    }
}
