﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;

namespace Faq.Models
{
    public class DBInit
    {
        public static void IntializeSporsmal(IServiceProvider serviceProvider)
        {
            using (var context = new DBModel(serviceProvider.GetRequiredService<DbContextOptions<DBModel>>()))
            {



                if (context.Sporsmaler.Any())
                {
                    return;
                }
                else
                {
                    var nyKategori1 = new Kategorier()
                    {
                        Navn = "Film"
                    };

                    var nyKategori2 = new Kategorier()
                    {
                        Navn = "Order"
                    };

                    var nyKategori3 = new Kategorier()
                    {
                        Navn = "Bruker"
                    };

                    var nySporsmal1 = new Sporsmaler()
                    {
                        Sporsmal = "Hva er en Film?",
                        Svar = "En film er noe man ser på",
                        Kategorier = nyKategori1,
                        Vurdering = true,
                        TommelOpp = 0,
                        TommelNed = 0
                    };

                    var nySporsmalFilm1 = new Sporsmaler()
                    {
                        Sporsmal = "Hvor kommer filmen fra?",
                        Svar = "Det kommer fra oss",
                        Kategorier = nyKategori1,
                        Vurdering = true,
                        TommelOpp = 0,
                        TommelNed = 0
                    };

                    var nySporsmalFilm2 = new Sporsmaler()
                    {
                        Sporsmal = "Hvordan kan du starte opp filmen?",
                        Svar = "Du starter opp ved å gå inn i profilen din",
                        Kategorier = nyKategori1,
                        Vurdering = true,
                        TommelOpp = 0,
                        TommelNed = 0
                    };

                    var nySporsmalFilm3 = new Sporsmaler()
                    {
                        Sporsmal = "Kan man laste ned filmen?",
                        Svar = "Ja, under din profil",
                        Kategorier = nyKategori1,
                        Vurdering = true,
                        TommelOpp = 0,
                        TommelNed = 0
                    };



                    var nySporsmal2 = new Sporsmaler()
                    {
                        Sporsmal = "Hvor finne man sine ordrer?",
                        Svar = "Ved å trykke på profilen sin",
                        Kategorier = nyKategori2,
                        Vurdering = true,
                        TommelOpp = 0,
                        TommelNed = 0
                    };

                    var nySporsmalOrder1 = new Sporsmaler()
                    {
                        Sporsmal = "Kan man slette sine ordrer?",
                        Svar = "Ja, ved å ta kontakt med oss",
                        Kategorier = nyKategori2,
                        Vurdering = true,
                        TommelOpp = 0,
                        TommelNed = 0
                    };

                    var nySporsmalOrder2 = new Sporsmaler()
                    {
                        Sporsmal = "Hva skal jeg gjøre dersom jeg ikke fine mine ordre?",
                        Svar = "Ta kontakt med oss.",
                        Kategorier = nyKategori2,
                        Vurdering = true,
                        TommelOpp = 0,
                        TommelNed = 0
                    };



                    var nySporsmal3 = new Sporsmaler()
                    {
                        Sporsmal = "Hva gjør jeg dersom jeg ikke kommer inn i brukeren min?",
                        Svar = "Ta kontakt med oss",
                        Kategorier = nyKategori3,
                        Vurdering = true,
                        TommelOpp = 0,
                        TommelNed = 0
                    };
                    var nySporsmalBruker1 = new Sporsmaler()
                    {
                        Sporsmal = "Kommer inn i brukeren, men ingenting stemmer?",
                        Svar = "Prøv å laste opp spørsmålene på nytt.",
                        Kategorier = nyKategori3,
                        Vurdering = false,
                        TommelOpp = 0,
                        TommelNed = 0
                    };
                    var nySporsmalBruker2 = new Sporsmaler()
                    {
                        Sporsmal = "Kan jeg slette brukeren?",
                        Svar = "Ja, ved å ta kontakt med oss",
                        Kategorier = nyKategori3,
                        Vurdering = true,
                        TommelOpp = 0,
                        TommelNed = 0
                    };
                    var nySporsmalBruker3 = new Sporsmaler()
                    {
                        Sporsmal = "Minstet epost, brukernavn eller passord?",
                        Svar = "Ta kontakt med oss.",
                        Kategorier = nyKategori3,
                        Vurdering = false,
                        TommelOpp = 0,
                        TommelNed = 0
                    };
                    var nySporsmalBruker4 = new Sporsmaler()
                    {
                        Sporsmal = "Brukeren vil ikke laste opp",
                        Svar = "Prøv å laste inn siden på nytt",
                        Kategorier = nyKategori3,
                        Vurdering = true,
                        TommelOpp = 0,
                        TommelNed = 0
                    };

                    var kategoriList = new List<Kategorier>();
                    kategoriList.Add(nyKategori1);
                    kategoriList.Add(nyKategori2);
                    kategoriList.Add(nyKategori3);

                    var sporsmalList = new List<Sporsmaler>();
                    sporsmalList.Add(nySporsmal1);
                    sporsmalList.Add(nySporsmalFilm1);
                    sporsmalList.Add(nySporsmalFilm2);
                    sporsmalList.Add(nySporsmalFilm3);
                    sporsmalList.Add(nySporsmal2);
                    sporsmalList.Add(nySporsmalOrder1);
                    sporsmalList.Add(nySporsmalOrder2);
                    sporsmalList.Add(nySporsmal3);
                    sporsmalList.Add(nySporsmalBruker1);
                    sporsmalList.Add(nySporsmalBruker2);
                    sporsmalList.Add(nySporsmalBruker3);
                    sporsmalList.Add(nySporsmalBruker4);

                    context.Kategorier.AddRange(kategoriList);
                    context.Sporsmaler.AddRange(sporsmalList);

                    context.SaveChanges();


                }




            }
    }
    }
}
