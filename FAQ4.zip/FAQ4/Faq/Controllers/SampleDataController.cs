using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Faq.Models;
using Microsoft.AspNetCore.Mvc;

namespace Faq.Controllers
{
    [Route("api/[controller]")]
    public class HomeController : Controller
    {
        private readonly DBModel _context;
        
        public HomeController(DBModel context)
        {
            _context = context;
        }

      //GET api/Home
        //id(1= film, 2= order, 3= bruker)
        [HttpGet("{kategori}")]
        public JsonResult Get(string kategori)
        {
            var sporsmolDb = new SporsmalDB(_context);
            List<Sporsmal> alleSporsmal;

            switch (kategori)
            {
                case "Film":
                    alleSporsmal = sporsmolDb.hentFilmerSporsmal();
                    break;
                case "Order":
                    alleSporsmal = sporsmolDb.hentOrderSporsmal();
                    break;
                case "Bruker":
                    alleSporsmal = sporsmolDb.hentBrukerSporsmal();
                    break;
                case "Alle":
                    alleSporsmal = sporsmolDb.hentAlleSporsmal();
                    break;
                default:
                    alleSporsmal = sporsmolDb.hentSporsmalEtterSok(kategori);
                    break;
            }

            return Json(alleSporsmal);
        }


        /*
        //GET api/Home
        [HttpGet("{tekst:alpha}")]
        public JsonResult Get(string tekst)
        {

            var sporsmolDb = new SporsmalDB(_context);
            //Ta tekste og legge til space
            List<Sporsmal> alleSporsmal = sporsmolDb.hentSporsmalEtterSok(tekst);

            return Json(alleSporsmal);
        }
        */


        // PUT api/Home/5
        [HttpPut("{id}")]
        public JsonResult Put(int id)
        {
            if (ModelState.IsValid)
            {
                var Db = new SporsmalDB(_context);
                bool OK = Db.setNyVurdering(id);
                if (OK)
                {
                    return Json("OK");
                }
            }
            return Json("Kunne ikke sett true til false eller omvendt");
        }
    }
}
