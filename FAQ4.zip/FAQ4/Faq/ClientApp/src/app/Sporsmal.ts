export class Sporsmal{
id:number;
sporsmal: string;
  svar: string;
  vurdering: boolean;
}
