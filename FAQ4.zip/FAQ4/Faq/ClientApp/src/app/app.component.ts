import { Component } from '@angular/core';
import { Http, Response } from '@angular/http';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import "rxjs/add/operator/map";
import { Sporsmal } from "./Sporsmal";
import { Headers } from "@angular/http";

@Component({
  selector: 'app',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  skjema: FormGroup;
  alleSporsmalListe: Array<Sporsmal>;
  alleSporsmalFilmerListe: Array<Sporsmal>;
  alleSporsmalOrderListe: Array<Sporsmal>;
  alleSporsmalBrukerListe: Array<Sporsmal>;
  alleSporsmalSokListe: Array<Sporsmal>;
  visHovedListe: boolean;
  visSokListe: boolean;
  finnerIngen: boolean;
  antall: number;
  public sokeTekst: string;

  constructor(private _http: Http, private fb: FormBuilder) {
    this.skjema = fb.group({
    });
  }


  ngOnInit() {
    this.hentSpørsmålListe();
    this.hentSpørsmålFilmListe();
    this.hentSpørsmålOrderListe();
    this.hentSpørsmålBrukerListe();
    this.visHovedListe = true;
    this.visSokListe = false;
    this.finnerIngen = false;
    

  }

  hentSpørsmålListe() {
    this._http.get("api/Home/" + "Alle")
      .subscribe(JsonData => {
        this.alleSporsmalListe = [];
        if (JsonData) {
          for (let spørsmålObject of JsonData.json()) {
            this.alleSporsmalListe.push(spørsmålObject);
          }
        };
      },
        error => alert(error),
        () => console.log("ferdig get-api/Home")

      );
  };

  hentSpørsmålFilmListe() {
    this._http.get("api/Home/" + "Film")
      .subscribe(JsonData => {
        this.alleSporsmalFilmerListe = [];
        if (JsonData) {
          for (let spørsmålObject of JsonData.json()) {
            this.alleSporsmalFilmerListe.push(spørsmålObject);
          }
        };
      },
        error => alert(error),
        () => console.log("ferdig get-api/Home")

      );
  };

  hentSpørsmålOrderListe() {
    this._http.get("api/Home/" + "Order")
      .subscribe(JsonData => {
        this.alleSporsmalOrderListe = [];
        if (JsonData) {
          for (let spørsmålObject of JsonData.json()) {
            this.alleSporsmalOrderListe.push(spørsmålObject);
          }
        };
      },
        error => alert(error),
        () => console.log("ferdig get-api/Home")

      );
  };

  hentSpørsmålBrukerListe() {
    this._http.get("api/Home/" + "Bruker")
      .subscribe(JsonData => {
        this.alleSporsmalBrukerListe = [];
        if (JsonData) {
          for (let spørsmålObject of JsonData.json()) {
            this.alleSporsmalBrukerListe.push(spørsmålObject);
          }
        };
      },
        error => alert(error),
        () => console.log("ferdig get-api/Home")

      );
  };


  hentSporsmalSokListe() {

    if (this.sokeTekst != "") {
      this.visHovedListe = false;
      this.visSokListe = true;

      this._http.get("api/Home/" + this.sokeTekst)
        .subscribe(JsonData => {
          this.alleSporsmalSokListe = [];
          if (JsonData) {

            this.antall = 0;
            this.finnerIngen = false;
            for (let spørsmålObject of JsonData.json()) {
              this.alleSporsmalSokListe.push(spørsmålObject);
              this.antall++;
            }

            if (this.antall < 1) {
              this.finnerIngen = true;
            }
          };
        },
          error => alert(error),
          () => console.log("ferdig get-api/Home")

        );
    } else {
      this.visHovedListe = true;
      this.visSokListe = false;
    }
    
  };



 
  setNyVurderingsVerdi(id: number) {
    var headers = new Headers({ "Content-Type": "application/json" });


    this._http.put("api/Home/" + id, headers)
      .subscribe(
      retur => {
        this.hentSpørsmålListe();
        this.hentSpørsmålFilmListe();
        this.hentSpørsmålOrderListe();
        this.hentSpørsmålBrukerListe();
      }
    ),
      error => alert(error),
      () => console.log("ferdig post-api/kunde")

    
  }

  setNyVurderingsSokVerdi(id: number) {
    var headers = new Headers({ "Content-Type": "application/json" });


    this._http.put("api/Home/" + id, headers)
      .subscribe(
        retur => {
          this.hentSpørsmålListe();
          this.hentSpørsmålFilmListe();
          this.hentSpørsmålOrderListe();
          this.hentSpørsmålBrukerListe();
          this.hentSporsmalSokListe();
        }
      ),
      error => alert(error),
      () => console.log("ferdig post-api/kunde")


  }




}
