﻿using Faq.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;

namespace Faq
{
   

    public class SporsmalDB
    {

        private readonly DBModel _context;

        public SporsmalDB(DBModel context)
        {
            _context = context;
        }

        public List<Sporsmal> hentAlleSporsmal()
        {
            List<Sporsmal> alleSporsmal = _context.Sporsmaler.Include(k => k.Kategorier).Select(k => new Sporsmal()
            {
                id = k.Id,
                sporsmal = k.Sporsmal,
                svar = k.Svar,
                vurdering = k.Vurdering,
                kategori = k.Kategorier.Navn

            }).ToList();
            return alleSporsmal;
        }

        public List<Sporsmal> hentFilmerSporsmal()
        {


            List<Sporsmal> alleSporsmal = _context.Sporsmaler.Where(k => k.Kategorier.Navn == "Film").Select(k => new Sporsmal()
            {
                id = k.Id,
                sporsmal = k.Sporsmal,
                svar = k.Svar,
                vurdering = k.Vurdering,
                kategori = k.Kategorier.Navn

            }).ToList();
            return alleSporsmal;
        }

        public List<Sporsmal> hentOrderSporsmal()
        {



            List<Sporsmal> alleSporsmal = _context.Sporsmaler.Where(k => k.Kategorier.Navn == "Order").Select(k => new Sporsmal()
            {
                id = k.Id,
                sporsmal = k.Sporsmal,
                svar = k.Svar,
                vurdering = k.Vurdering,
                kategori = k.Kategorier.Navn

            }).ToList();
            return alleSporsmal;
        }

        public List<Sporsmal> hentBrukerSporsmal()
        {



            List<Sporsmal> alleSporsmal = _context.Sporsmaler.Where(k => k.Kategorier.Navn == "Bruker").Select(k => new Sporsmal()
            {
                id = k.Id,
                sporsmal = k.Sporsmal,
                svar = k.Svar,
                vurdering = k.Vurdering,
                kategori = k.Kategorier.Navn

            }).ToList();
            return alleSporsmal;
        }

        public List<Sporsmal> hentSporsmalEtterSok(string tekst)
        {

            List<Sporsmal> alleSporsmal = _context.Sporsmaler.Where(k => k.Sporsmal.Contains(tekst) || k.Sporsmal == tekst).Select(k => new Sporsmal()
            {
                id = k.Id,
                sporsmal = k.Sporsmal,
                svar = k.Svar,
                vurdering = k.Vurdering,
                kategori = k.Kategorier.Navn

            }).ToList();
            return alleSporsmal;
        }
        
        public bool setNyVurdering(int id)
        {
            Sporsmaler funnetSporsmal = _context.Sporsmaler.FirstOrDefault(k=> k.Id == id);
            if(funnetSporsmal == null)
            {
                return false;
            }

            funnetSporsmal.Vurdering = !funnetSporsmal.Vurdering;
            try
            {
                _context.SaveChanges();
            }catch(Exception feil)
            {
                return false;
            }

            return true;
        
        }
    }
}
