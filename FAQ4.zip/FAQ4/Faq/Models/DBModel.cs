﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Faq.Models
{

    public class Sporsmaler
    {
        [Key]
        public int Id { get; set; }
        public string Sporsmal { get; set; }
        public string Svar { get; set; }
        public bool Vurdering { get; set; }


        public virtual Kategorier Kategorier { get; set; }


    }

    public class Kategorier
    {
        [Key]
        public int Id { get; set; }
        public string Navn { get; set; }

        public virtual List<Sporsmaler> Sporsmaler { get; set; }
    }


    public class DBModel: DbContext
    {
        public DBModel(DbContextOptions<DBModel> options)
            : base(options) { }

        public DbSet<Sporsmaler> Sporsmaler { get; set; }
        public DbSet<Kategorier> Kategorier { get; set; }
    }
}
