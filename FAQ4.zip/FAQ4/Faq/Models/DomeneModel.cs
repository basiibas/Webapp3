﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Faq.Models
{
    public class Sporsmal
    {
        
        public int id { get; set; }
    
        public string sporsmal { get; set; }

        public string svar { get; set; }

        public string kategori { get; set; }

        public bool vurdering { get; set; }
    }

    public class Kategori
    {
        public int id { get; set; }
        public string navn { get; set; }

    }

    
}
